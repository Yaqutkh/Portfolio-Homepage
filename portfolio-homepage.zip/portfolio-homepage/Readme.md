# Portfolio Homepage Project

This is a portfolio homepage project built using HTML, SCSS, and PostCSS. The project demonstrates a clean, responsive design following the BEM methodology for organizing CSS classes.

## Project Setup

1. Clone the repository.
2. Install dependencies:
   ```bash
   npm install


